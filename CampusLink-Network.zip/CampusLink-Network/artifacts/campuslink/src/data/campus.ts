export interface Campus {
  id: string;
  name: string;
  shortName: string;
  city: string;
  region: string;
  country: string;
}

export interface CampusScoped {
  campusId: Campus["id"];
}

export interface SampleStudent extends CampusScoped {
  initials: string;
  name: string;
  course: string;
  year: string;
  location: string;
  interests: string[];
  color: string;
  mutual: string;
}

export interface SampleLecture extends CampusScoped {
  code: string;
  title: string;
  detail: string;
  time: string;
  room: string;
  people: number;
  color: string;
}

export interface SampleConversation extends CampusScoped {
  name: string;
  initials: string;
  color: string;
  preview: string;
  time: string;
  unread: boolean;
}

export interface SampleCommunity extends CampusScoped {
  id: string;
  name: string;
  category: string;
  description: string;
  members: number;
  color: string;
}

// Campus-scoped records keep the UCC preview ready to grow without treating
// university names as a global constant throughout the UI.
export const campuses: Campus[] = [
  {
    id: "ucc",
    name: "University of Cape Coast",
    shortName: "UCC",
    city: "Cape Coast",
    region: "Central Region",
    country: "Ghana",
  },
];

const configuredCampus = campuses.find((campus) => campus.id === "ucc");

if (!configuredCampus) {
  throw new Error("The CampusLink preview campus has not been configured.");
}

export const activeCampus: Campus = configuredCampus;

export const students: SampleStudent[] = [
  {
    campusId: activeCampus.id,
    initials: "AM",
    name: "Ama Mensah",
    course: "BSc. Computer Science",
    year: "Level 300",
    location: "Cape Coast",
    interests: ["Product design", "Afrobeats", "Tech for good"],
    color: "coral",
    mutual: "Same course",
  },
  {
    campusId: activeCampus.id,
    initials: "KQ",
    name: "Kojo Quaye",
    course: "BSc. Information Technology",
    year: "Level 200",
    location: "Elmina",
    interests: ["Football", "Startups", "Photography"],
    color: "blue",
    mutual: "2 shared lectures",
  },
  {
    campusId: activeCampus.id,
    initials: "EA",
    name: "Esi Agyeman",
    course: "BA. Communication Studies",
    year: "Level 300",
    location: "Cape Coast",
    interests: ["Writing", "Film", "Public speaking"],
    color: "lilac",
    mutual: "Same course",
  },
  {
    campusId: activeCampus.id,
    initials: "NY",
    name: "Nana Yeboah",
    course: "BSc. Economics",
    year: "Level 400",
    location: "Kotokuraba",
    interests: ["Data", "Basketball", "Reading"],
    color: "mint",
    mutual: "2 shared lectures",
  },
];

export const lectures: SampleLecture[] = [
  {
    campusId: activeCampus.id,
    code: "CSC 305",
    title: "Human Computer Interaction",
    detail: "Design principles, usability testing and interfaces",
    time: "Mon & Wed · 10:00 AM",
    room: "Science Lecture Theatre 2",
    people: 18,
    color: "blue",
  },
  {
    campusId: activeCampus.id,
    code: "CSC 311",
    title: "Database Systems",
    detail: "Relational models, SQL and data architecture",
    time: "Tue & Thu · 1:00 PM",
    room: "School of Physical Sciences",
    people: 24,
    color: "mint",
  },
  {
    campusId: activeCampus.id,
    code: "GNS 302",
    title: "African Studies",
    detail: "Culture, identity and contemporary Ghana",
    time: "Friday · 8:00 AM",
    room: "Old Site, LT A",
    people: 32,
    color: "peach",
  },
];

export const conversations: SampleConversation[] = [
  {
    campusId: activeCampus.id,
    name: "Ama Mensah",
    initials: "AM",
    color: "coral",
    preview: "That HCI reading was a lot. Have you...",
    time: "10:42",
    unread: true,
  },
  {
    campusId: activeCampus.id,
    name: "Kojo Quaye",
    initials: "KQ",
    color: "blue",
    preview: "See you in the library later?",
    time: "Yesterday",
    unread: false,
  },
  {
    campusId: activeCampus.id,
    name: "CSC 305 Study Circle",
    initials: "C3",
    color: "mint",
    preview: "Nana: I found a good article for...",
    time: "Tue",
    unread: false,
  },
];

export const communities: SampleCommunity[] = [
  {
    campusId: activeCampus.id,
    id: "ucc-women-in-tech",
    name: "Women in Tech",
    category: "TECH & CAREERS",
    description: "Ideas, support and new opportunities in technology.",
    members: 128,
    color: "sky",
  },
  {
    campusId: activeCampus.id,
    id: "ucc-campus-creatives",
    name: "Campus Creatives",
    category: "ARTS & CULTURE",
    description: "A home for makers, storytellers and curious minds.",
    members: 86,
    color: "lilac",
  },
  {
    campusId: activeCampus.id,
    id: "ucc-csc-305-study-circle",
    name: "CSC 305 Study Circle",
    category: "STUDY GROUP",
    description: "Work through HCI concepts with fellow students.",
    members: 32,
    color: "mint",
  },
];
