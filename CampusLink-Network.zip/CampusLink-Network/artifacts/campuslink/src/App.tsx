import { useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from "react";
import { ClerkProvider, SignIn, SignUp, useAuth, useClerk, useUser } from "@clerk/react";
import { publishableKeyFromHost } from "@clerk/react/internal";
import { shadcn } from "@clerk/themes";
import { QueryClient, QueryClientProvider, useQueryClient } from "@tanstack/react-query";
import { ArrowRight, BookOpen, Check, ChevronDown, Compass, GraduationCap, Home, LoaderCircle, LogOut, MapPin, Menu, MessageCircle, ShieldCheck, Users, X } from "lucide-react";
import { Link, Redirect, Route, Router as WouterRouter, Switch, useLocation } from "wouter";
import {
  getGetMyStudentProfileQueryKey,
  getGetMyVerificationStatusQueryKey,
  getListUniversitiesQueryKey,
  useCreateMyStudentProfile,
  useGetMyStudentProfile,
  useGetMyVerificationStatus,
  useListUniversities,
  useUpdateMyStudentProfile,
} from "@workspace/api-client-react";
import { ErrorBoundary } from "@/components/error-boundary";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient();
const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");
const clerkPubKey = publishableKeyFromHost(window.location.hostname, import.meta.env.VITE_CLERK_PUBLISHABLE_KEY);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;
const nav = [
  { href: "/home", label: "Home", icon: Home },
  { href: "/discover", label: "Discover students", icon: Compass },
  { href: "/lecture-connect", label: "Lecture connect", icon: BookOpen },
  { href: "/messages", label: "Messages", icon: MessageCircle },
  { href: "/profile", label: "My profile", icon: Users },
];
const appearance = {
  theme: shadcn,
  cssLayerName: "clerk",
  options: {
    logoPlacement: "inside" as const,
    logoLinkUrl: basePath || "/",
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
  },
  variables: {
    colorPrimary: "#267fad",
    colorForeground: "#203650",
    colorMutedForeground: "#71849a",
    colorDanger: "#b85c54",
    colorBackground: "#fff",
    colorInput: "#f7fafc",
    colorInputForeground: "#203650",
    colorNeutral: "#dce7ef",
    fontFamily: "DM Sans, sans-serif",
    borderRadius: "0.7rem",
  },
  elements: {
    rootBox: "campus-clerk-root",
    cardBox: "campus-clerk-cardbox",
    card: "!shadow-none !border-0 !bg-transparent",
    footer: "!shadow-none !border-0 !bg-transparent",
    headerTitle: "campus-clerk-title",
    headerSubtitle: "campus-clerk-subtitle",
    socialButtonsBlockButtonText: "campus-clerk-text",
    formFieldLabel: "campus-clerk-text",
    footerActionLink: "campus-clerk-link",
    footerActionText: "campus-clerk-muted",
    dividerText: "campus-clerk-muted",
    identityPreviewEditButton: "campus-clerk-link",
    formFieldSuccessText: "campus-clerk-text",
    alertText: "campus-clerk-text",
    logoBox: "campus-clerk-logo",
    logoImage: "campus-clerk-logo-image",
    socialButtonsBlockButton: "campus-clerk-social",
    formButtonPrimary: "campus-clerk-submit",
    formFieldInput: "campus-clerk-input",
    footerAction: "campus-clerk-footer-action",
    dividerLine: "campus-clerk-divider",
    alert: "campus-clerk-alert",
    otpCodeFieldInput: "campus-clerk-input",
    formFieldRow: "campus-clerk-field",
    main: "campus-clerk-main",
  },
};

function stripBase(path: string) {
  return basePath && path.startsWith(basePath) ? path.slice(basePath.length) || "/" : path;
}

function Brand({ inverse = false }: { inverse?: boolean }) {
  return <Link href="/" className={`brand ${inverse ? "brand-inverse" : ""}`} aria-label="CampusLink home"><span className="brand-mark"><i /><i /><i /></span><span>campus<span>link</span></span></Link>;
}

function LoadingPanel({ label = "Getting your campus space ready" }: { label?: string }) {
  return <main className="state-screen"><div className="state-card"><span className="state-mark"><LoaderCircle size={21} /></span><p>{label}</p><div className="skeleton-line" /><div className="skeleton-line short" /></div></main>;
}

function PublicLanding() {
  const { isLoaded, isSignedIn } = useAuth();
  const [, setLocation] = useLocation();
  const { data: profile, isLoading, isError } = useGetMyStudentProfile({ query: { queryKey: getGetMyStudentProfileQueryKey(), enabled: isLoaded && !!isSignedIn } });
  if (isLoaded && isSignedIn && isLoading) return <LoadingPanel />;
  if (isLoaded && isSignedIn) return <Redirect to={profile && !isError ? "/home" : "/onboarding"} />;
  return <div className="landing">
    <header className="landing-nav"><Brand /><nav><a href="#how">How it works</a><a href="#ucc">Our first campus</a></nav><div className="landing-actions"><Link href="/login" className="nav-login">Log in</Link><Link href="/register" className="button-primary">Join CampusLink <ArrowRight size={16} /></Link></div></header>
    <main>
      <section className="landing-hero"><div className="landing-copy"><span className="preview-tag"><i /> MADE FOR UCC STUDENTS</span><span className="hero-kicker"><i /> UNIVERSITY OF CAPE COAST · GHANA</span><h1>Campus feels<br />better when<br /><em>you belong.</em></h1><p>Find classmates, study partners and the communities that make a big campus feel like yours. CampusLink is beginning at UCC.</p><div className="hero-actions"><Link href="/register" className="button-primary">Create your account <ArrowRight size={16} /></Link><Link href="/login" className="button-quiet">Already a member? Sign in</Link></div><div className="hero-proof"><span className="proof-symbol"><MapPin size={16} /></span><span><b>Starting at the University of Cape Coast</b><small>Built around the everyday life of campus.</small></span></div></div>
        <div className="landing-art" aria-label="Abstract CampusLink campus illustration"><div className="art-topline"><span>CAMPUSLINK / 001</span><span>05° 06' N — 01° 15' W</span></div><div className="campus-scene"><div className="scene-sun" /><div className="scene-ring ring-one" /><div className="scene-ring ring-two" /><div className="scene-building building-one" /><div className="scene-building building-two" /><div className="scene-building building-three" /><div className="scene-path" /><span className="scene-label scene-label-a">01 — FIND YOUR PEOPLE</span><span className="scene-label scene-label-b">CAPE COAST / GHANA</span><div className="scene-center"><span className="brand-mark"><i /><i /><i /></span><b>It starts here.</b></div></div><div className="art-bottomline"><span>UCC STUDENT COMMONS</span><span>YOUR CAMPUS, CLOSER</span></div></div>
      </section>
      <section className="landing-points"><div><b>People in your orbit</b><span>Meet classmates beyond the lecture hall.</span></div><div><b>Study, side by side</b><span>Make room for better questions.</span></div><div><b>Your kind of community</b><span>Find the interests you share.</span></div><span className="point-index">01 / 03</span></section>
      <section className="how-section" id="how"><div><span className="eyebrow">A DIFFERENT KIND OF CAMPUS NETWORK</span><h2>Not another feed.<br /><em>A better way to find your people.</em></h2><p>CampusLink brings the everyday parts of student life into one thoughtful place. Create your account, build your own profile, and see your verification status clearly.</p></div><div className="how-list"><article><span>01</span><div><h3>Start with your university</h3><p>Choose from the live university directory before creating an account.</p></div><ArrowRight size={17} /></article><article><span>02</span><div><h3>Make it yours</h3><p>Add your name, program, level and the details you want classmates to know.</p></div><ArrowRight size={17} /></article><article><span>03</span><div><h3>Know where you stand</h3><p>Your profile shows the current verification status. A university selection is not proof of enrollment.</p></div><ArrowRight size={17} /></article></div></section>
      <section className="ucc-section" id="ucc"><div className="ucc-orbit"><span className="orbit-label orbit-top">CAPE COAST</span><span className="orbit-label orbit-right">UCC</span><span className="orbit-label orbit-bottom">GHANA</span><span className="orbit-core"><GraduationCap size={32} /></span></div><div className="ucc-copy"><span className="eyebrow">OUR FIRST CAMPUS</span><h2>Starting where<br />the Atlantic <em>meets campus.</em></h2><p>University of Cape Coast is where we begin: a campus full of stories, new beginnings and people worth meeting. The first step is a student profile; verification processes will follow when UCC selects an approved method.</p><Link href="/register" className="text-link">Get started at UCC <ArrowRight size={16} /></Link><div className="ucc-address"><MapPin size={17} /><span><b>University of Cape Coast</b><small>Cape Coast, Central Region, Ghana</small></span></div></div></section>
      <section className="landing-cta"><span className="eyebrow">A NOTE FROM US</span><h2>Campus is a lot of things.<br /><em>You don't have to figure it out alone.</em></h2><p>Make a profile and find the people and spaces that help campus feel closer.</p><Link href="/register" className="button-primary">Create your account <ArrowRight size={16} /></Link><div className="cta-stamp">UCC<br />FIRST</div></section>
    </main><footer className="landing-footer"><Brand /><span>Made for campus. Starting in Cape Coast.</span><div><Link href="/login">Log in</Link><Link href="/register">Register</Link></div><small>© 2025 CampusLink</small></footer>
  </div>;
}

function RegistrationPage() {
  const { isLoaded, isSignedIn } = useAuth();
  const [, setLocation] = useLocation();
  const universities = useListUniversities({ query: { queryKey: getListUniversitiesQueryKey() } });
  const [selected, setSelected] = useState("");
  if (isLoaded && isSignedIn) return <Redirect to="/onboarding" />;
  const list = universities.data ?? [];
  return <div className="auth-layout"><aside className="auth-story"><Brand /><Link href="/" className="back-link">← Back to CampusLink</Link><div className="auth-story-content"><span className="eyebrow">YOUR CAMPUS, CLOSER</span><h1>Choose your<br />university first.</h1><p>CampusLink starts by anchoring your account to a real university choice. This selection does not verify enrollment.</p><div className="story-orbit"><div /><div /><span className="brand-mark"><i /><i /><i /></span><small>UCC · CAPE COAST</small></div></div><small className="auth-story-foot">CAMPUSLINK / A DIGITAL CAMPUS COMMONS</small></aside><main className="auth-main"><div className="auth-form"><span className="form-kicker">STEP 01 <i /> UNIVERSITY</span><h2>Where do you study?</h2><p className="form-description">Choose the university to continue to secure account creation.</p>
    {universities.isLoading ? <div className="university-loading"><div /><div /><div /></div> : universities.isError ? <div className="inline-error"><b>Universities could not load.</b><span>Check your connection and try again.</span><button onClick={() => universities.refetch()}>Retry</button></div> : <div className="university-options">{list.map(university => <button type="button" key={university.id} onClick={() => setSelected(university.id)} className={`university-option ${selected === university.id ? "chosen" : ""}`} data-testid={`university-${university.id}`}><span className="university-icon"><GraduationCap size={20} /></span><span className="university-copy"><b>{university.name}</b><small>{university.city}, {university.country}</small></span><span className="choice-indicator">{selected === university.id && <Check size={15} />}</span></button>)}</div>}
    <div className="verification-explainer"><ShieldCheck size={18} /><p><b>Selection is not verification.</b><br />UCC has not configured an approved verification method yet. New accounts stay pending.</p></div><button type="button" className="button-primary auth-continue" disabled={!selected || universities.isLoading} onClick={() => setLocation(`/sign-up?universityId=${encodeURIComponent(selected)}`)}>Continue to create account <ArrowRight size={16} /></button><p className="auth-switch">Already have an account? <Link href="/login">Sign in</Link></p></div></main></div>;
}

function ClerkAuthPage({ register = false }: { register?: boolean }) {
  const universityId = new URLSearchParams(window.location.search).get("universityId");
  const redirectTarget = `${basePath}/onboarding${universityId ? `?universityId=${encodeURIComponent(universityId)}` : ""}`;
  const universities = useListUniversities({ query: { queryKey: getListUniversitiesQueryKey(), enabled: register } });
  if (register && !universityId) return <Redirect to="/register" />;
  if (register && universities.isLoading) return <LoadingPanel label="Confirming your university selection" />;
  if (register && (!universities.data?.some(university => university.id === universityId) || universities.isError)) return <Redirect to="/register" />;
  return <div className="clerk-page"><div className="clerk-page-head"><Brand /><Link href="/" className="back-link">Back to CampusLink</Link></div><div className="clerk-page-content"><div className="clerk-side-copy"><span className="eyebrow">{register ? "START AT YOUR UNIVERSITY" : "WELCOME BACK"}</span><h1>{register ? "A more connected campus starts here." : "Your campus, your people."}</h1><p>{register ? "Create a secure account, then build your own student profile." : "Sign in to continue to your CampusLink profile."}</p><div className="verification-explainer"><ShieldCheck size={18} /><p><b>Verification stays transparent.</b><br />Choosing a university does not confirm enrollment. UCC accounts remain pending until an approved method is available.</p></div></div><div className="clerk-widget">{register ? <SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} forceRedirectUrl={redirectTarget} /> : <SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/register`} forceRedirectUrl={`${basePath}/`} />}</div></div></div>;
}

function AccountMenu() {
  const { signOut } = useClerk();
  const { user } = useUser();
  const name = user?.fullName || user?.primaryEmailAddress?.emailAddress || "Student account";
  const initials = name.split(/[\s@._-]+/).filter(Boolean).slice(0, 2).map(part => part[0]).join("").toUpperCase() || "S";
  return <div className="account-row"><span className="account-avatar">{initials}</span><span className="account-name"><b>{name}</b><small>Signed-in account</small></span><button type="button" className="signout-button" onClick={() => signOut({ redirectUrl: basePath || "/" })} aria-label="Sign out" title="Sign out"><LogOut size={17} /></button></div>;
}

function AppShell({ current, children }: { current: string; children: ReactNode }) {
  const [open, setOpen] = useState(false);
  return <div className="private-shell"><aside className="private-sidebar"><Brand /><div className="campus-selector"><span /> UNIVERSITY SPACE <ChevronDown size={14} /></div><div className="side-caption">YOUR CAMPUS</div><nav className="private-nav">{nav.map(({ href, label, icon: Icon }) => <Link href={href} key={href} className={`private-nav-link ${href === current ? "selected" : ""}`}><Icon size={18} />{label}</Link>)}</nav><div className="sidebar-bottom"><div className="side-note"><ShieldCheck size={17} /><b>Verification update</b><p>UCC has not selected an approved student verification method yet.</p></div><AccountMenu /></div></aside><main className="private-main"><div className="mobile-top"><button className="icon-button" onClick={() => setOpen(!open)} aria-label="Toggle navigation"><Menu size={20} /></button><Brand /><AccountMenu /></div>{open && <nav className="mobile-drawer"><button className="drawer-close" onClick={() => setOpen(false)}><X size={17} /> Close</button>{nav.map(({ href, label, icon: Icon }) => <Link href={href} onClick={() => setOpen(false)} key={href}><Icon size={18} />{label}</Link>)}</nav>}{children}</main></div>;
}

function OwnProfile({ embedded = false }: { embedded?: boolean }) {
  const profileQuery = useGetMyStudentProfile({ query: { queryKey: getGetMyStudentProfileQueryKey() } });
  const verificationQuery = useGetMyVerificationStatus({ query: { queryKey: getGetMyVerificationStatusQueryKey() } });
  const update = useUpdateMyStudentProfile();
  const [editing, setEditing] = useState(false);
  const [message, setMessage] = useState("");
  const profile = profileQuery.data;
  const [form, setForm] = useState({ displayName: "", program: "", academicLevel: "", bio: "" });
  const profileForm = useMemo(() => profile ? { displayName: profile.displayName, program: profile.program, academicLevel: profile.academicLevel, bio: profile.bio ?? "" } : null, [profile]);
  if (profileQuery.isLoading) return <LoadingPanel label="Loading your profile" />;
  if (profileQuery.isError || !profile) return <div className="inline-error"><b>Your profile could not be loaded.</b><span>Please retry in a moment.</span><button onClick={() => profileQuery.refetch()}>Retry</button></div>;
  const status = verificationQuery.data?.status ?? profile.verificationStatus;
  const isPending = status === "pending";
  const beginEdit = () => { if (profileForm) setForm(profileForm); setMessage(""); setEditing(true); };
  const save = (event: FormEvent) => {
    event.preventDefault();
    update.mutate({ data: { displayName: form.displayName.trim(), program: form.program.trim(), academicLevel: form.academicLevel.trim(), bio: form.bio.trim() || null } }, {
      onSuccess: () => { setEditing(false); setMessage("Your profile has been updated."); void queryClient.invalidateQueries({ queryKey: getGetMyStudentProfileQueryKey() }); },
      onError: () => setMessage("We could not save those changes. Please try again."),
    });
  };
  return <div className={`profile-page ${embedded ? "profile-embedded" : ""}`}><div className="private-header"><div><span className="eyebrow">{embedded ? "YOUR CAMPUSLINK SPACE" : "YOUR PROFILE"}</span><h1>{embedded ? `Welcome, ${profile.displayName.split(" ")[0]}.` : "Student profile"}</h1></div>{!editing && <button className="outline-button" onClick={beginEdit}>Edit profile</button>}</div><section className="profile-hero"><div className="profile-avatar">{profile.displayName.split(/\s+/).map(part => part[0]).slice(0, 2).join("").toUpperCase()}</div><div><span className="profile-university">{profile.universityName}</span><h2>{profile.displayName}</h2><p>{profile.program} <span>·</span> {profile.academicLevel}</p></div><span className={`status-pill ${isPending ? "pending" : status === "verified" ? "verified" : "rejected"}`}><i />{status}</span></section>
    <div className="status-panel"><div className="status-icon"><ShieldCheck size={19} /></div><div><span className="eyebrow">UNIVERSITY VERIFICATION</span><h3>{isPending ? "Pending — no approved method yet" : `Status: ${status}`}</h3><p>{isPending ? `${profile.universityName} has not configured an approved verification method. Your account remains pending. Choosing a university creates no proof of enrollment.` : `This is your current verification status for ${profile.universityName}.`}</p></div></div>
    {message && <p className="form-feedback" role="status">{message}</p>}
    {editing ? <form className="profile-edit-form" onSubmit={save}><label>Display name<input required maxLength={100} value={form.displayName} onChange={e => setForm({ ...form, displayName: e.target.value })} /></label><label>Program<input required maxLength={140} value={form.program} onChange={e => setForm({ ...form, program: e.target.value })} /></label><label>Academic level<input required maxLength={60} value={form.academicLevel} onChange={e => setForm({ ...form, academicLevel: e.target.value })} /></label><label className="wide-field">Bio <span>Optional</span><textarea maxLength={500} rows={4} value={form.bio} onChange={e => setForm({ ...form, bio: e.target.value })} placeholder="A little about what you enjoy or hope to find on campus" /></label><div className="form-actions"><button type="button" className="text-button" onClick={() => setEditing(false)}>Cancel</button><button type="submit" className="button-primary" disabled={update.isPending}>{update.isPending ? "Saving…" : "Save profile"} <ArrowRight size={15} /></button></div></form> : <div className="profile-details"><section><span className="eyebrow">A FEW WORDS</span><p>{profile.bio || "No bio added yet."}</p></section><section><span className="eyebrow">STUDYING</span><b>{profile.program}</b><small>{profile.academicLevel}</small></section><section><span className="eyebrow">CAMPUS</span><b>{profile.universityName}</b><small>{verificationQuery.isLoading ? "Checking verification status…" : `Verification: ${status}`}</small></section></div>}
    {verificationQuery.isError && <div className="inline-error compact"><span>Verification status is temporarily unavailable; the profile status remains {profile.verificationStatus}.</span><button onClick={() => verificationQuery.refetch()}>Retry</button></div>}
    <div className="privacy-note"><ShieldCheck size={17} /><p><b>Your profile is your own.</b> Verification is pending. Student discovery and sample campus activity are not available as real people or real records at this stage.</p></div>
  </div>;
}

function ProtectedRoute({ path }: { path: string }) {
  const { isLoaded, isSignedIn } = useAuth();
  const { data: profile, isLoading, isError, isFetching } = useGetMyStudentProfile({ query: { queryKey: getGetMyStudentProfileQueryKey(), enabled: isLoaded && !!isSignedIn } });
  if (!isLoaded || (isSignedIn && (isLoading || isFetching))) return <LoadingPanel />;
  if (!isSignedIn) return <Redirect to="/login" />;
  if (!profile || isError) return <Redirect to="/onboarding" />;
  if (path === "/profile") return <AppShell current={path}><OwnProfile /></AppShell>;
  const current = nav.find(item => item.href === path);
  return <AppShell current={path}><section className="private-header"><div><span className="eyebrow">YOUR CAMPUSLINK SPACE</span><h1>{path === "/home" ? `Welcome, ${profile.displayName.split(" ")[0]}.` : current?.label}</h1></div></section><section className="pending-gate"><span className="gate-icon"><ShieldCheck size={22} /></span><span className="eyebrow">PRIVATE CAMPUS FEATURES</span><h2>Student connections are not open yet.</h2><p>University of Cape Coast has not configured an approved verification method. Your account is pending, so discovery, communities, lecture connections and messaging are not presented as real student activity.</p><div className="gate-status"><span className="status-pill pending"><i /> Pending verification</span><span>{profile.universityName}</span></div><Link href="/profile" className="button-primary">View your profile and status <ArrowRight size={15} /></Link></section></AppShell>;
}

function OnboardingPage() {
  const { isLoaded, isSignedIn } = useAuth();
  const [, setLocation] = useLocation();
  const profileQuery = useGetMyStudentProfile({ query: { queryKey: getGetMyStudentProfileQueryKey(), enabled: isLoaded && !!isSignedIn } });
  const universities = useListUniversities({ query: { queryKey: getListUniversitiesQueryKey() } });
  const createProfile = useCreateMyStudentProfile();
  const [universityId, setUniversityId] = useState(new URLSearchParams(window.location.search).get("universityId") ?? "");
  const [displayName, setDisplayName] = useState("");
  const [program, setProgram] = useState("");
  const [academicLevel, setAcademicLevel] = useState("");
  const [bio, setBio] = useState("");
  const [error, setError] = useState("");
  if (!isLoaded) return <LoadingPanel />;
  if (!isSignedIn) return <Redirect to="/login" />;
  if (profileQuery.isLoading) return <LoadingPanel label="Checking your student profile" />;
  if (profileQuery.data) return <Redirect to="/profile" />;
  const submit = (event: FormEvent) => {
    event.preventDefault();
    setError("");
    createProfile.mutate({ data: { universityId, displayName: displayName.trim(), program: program.trim(), academicLevel: academicLevel.trim(), ...(bio.trim() ? { bio: bio.trim() } : {}) } }, {
      onSuccess: async () => {
        await Promise.all([
          queryClient.invalidateQueries({ queryKey: getGetMyStudentProfileQueryKey() }),
          queryClient.invalidateQueries({ queryKey: getGetMyVerificationStatusQueryKey() }),
        ]);
        setLocation("/profile");
      },
      onError: () => setError("We could not create your profile. Please review your details and try again."),
    });
  };
  return <div className="onboarding-layout"><header className="onboarding-top"><Brand /><div className="onboarding-step">YOUR PROFILE <span>01 / 01</span></div></header><main className="onboarding-main"><div className="onboarding-intro"><span className="eyebrow">WELCOME TO CAMPUSLINK</span><h1>Make this space<br /><em>feel like yours.</em></h1><p>Your university and profile details help shape your CampusLink space. You can update your profile later.</p></div><form className="onboarding-form" onSubmit={submit}><div className="form-progress"><span /><i /></div><div className="form-section-heading"><span>01</span><div><b>Your student profile</b><small>These details belong to your signed-in account.</small></div></div>
    <label>University<select required value={universityId} onChange={e => setUniversityId(e.target.value)} disabled={universities.isLoading}><option value="">Select your university</option>{(universities.data ?? []).map(university => <option value={university.id} key={university.id}>{university.name} · {university.city}</option>)}</select></label>{universities.isError && <div className="inline-error compact"><span>University list failed to load.</span><button type="button" onClick={() => universities.refetch()}>Retry</button></div>}
    <div className="form-pair"><label>Display name<input required maxLength={100} value={displayName} onChange={e => setDisplayName(e.target.value)} placeholder="How classmates should know you" /></label><label>Program<input required maxLength={140} value={program} onChange={e => setProgram(e.target.value)} placeholder="e.g. BSc. Computer Science" /></label></div><label>Academic level<input required maxLength={60} value={academicLevel} onChange={e => setAcademicLevel(e.target.value)} placeholder="e.g. Level 300" /></label><label>Bio <span className="optional-label">OPTIONAL</span><textarea maxLength={500} rows={4} value={bio} onChange={e => setBio(e.target.value)} placeholder="A little about what you enjoy or hope to find on campus" /></label>
    <div className="verification-explainer"><ShieldCheck size={19} /><p><b>Your profile starts pending.</b><br />Selecting a university is not proof of enrollment. UCC does not yet have an approved verification method.</p></div>{error && <div className="inline-error"><span>{error}</span></div>}<button type="submit" className="button-primary auth-continue" disabled={createProfile.isPending || universities.isLoading || !universityId}>{createProfile.isPending ? "Creating your profile…" : "Create my profile"} <ArrowRight size={16} /></button></form></main></div>;
}

function AuthRouteGate({ children }: { children: ReactNode }) {
  const { isLoaded, isSignedIn } = useAuth();
  const { data: profile, isLoading, isError } = useGetMyStudentProfile({ query: { queryKey: getGetMyStudentProfileQueryKey(), enabled: isLoaded && !!isSignedIn } });
  if (!isLoaded) return <LoadingPanel />;
  if (!isSignedIn) return <>{children}</>;
  if (isLoading) return <LoadingPanel />;
  return <Redirect to={profile && !isError ? "/home" : "/onboarding"} />;
}

function QueryCacheSync() {
  const { addListener } = useClerk();
  const client = useQueryClient();
  const previousUserId = useRef<string | null | undefined>(undefined);
  useEffect(() => {
    const unsubscribe = addListener(({ user }) => {
      const id = user?.id ?? null;
      if (previousUserId.current !== undefined && previousUserId.current !== id) client.clear();
      previousUserId.current = id;
    });
    return unsubscribe;
  }, [addListener, client]);
  return null;
}

function RouterContent() {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}><Switch>
    <Route path="/" component={PublicLanding} />
    <Route path="/login" component={() => <Redirect to="/sign-in" />} />
    <Route path="/register" component={RegistrationPage} />
    <Route path="/sign-in/*?" component={() => <AuthRouteGate><ClerkAuthPage /></AuthRouteGate>} />
    <Route path="/sign-up/*?" component={() => <AuthRouteGate><ClerkAuthPage register /></AuthRouteGate>} />
    <Route path="/onboarding" component={OnboardingPage} />
    <Route path="/home" component={() => <ProtectedRoute path="/home" />} />
    <Route path="/discover" component={() => <ProtectedRoute path="/discover" />} />
    <Route path="/lecture-connect" component={() => <ProtectedRoute path="/lecture-connect" />} />
    <Route path="/messages" component={() => <ProtectedRoute path="/messages" />} />
    <Route path="/profile" component={() => <ProtectedRoute path="/profile" />} />
    <Route component={NotFound} />
  </Switch></ErrorBoundary>;
}

function ClerkRouter() {
  const [, setLocation] = useLocation();
  return <ClerkProvider
    publishableKey={clerkPubKey}
    proxyUrl={clerkProxyUrl}
    appearance={appearance}
    signInUrl={`${basePath}/sign-in`}
    signUpUrl={`${basePath}/register`}
    signInForceRedirectUrl={`${basePath}/`}
    signUpForceRedirectUrl={`${basePath}/onboarding`}
    localization={{
      signIn: { start: { title: "Welcome back", subtitle: "Sign in to your CampusLink account" } },
      signUp: { start: { title: "Create your account", subtitle: "Your university community starts here" } },
    }}
    routerPush={to => setLocation(stripBase(to))}
    routerReplace={to => setLocation(stripBase(to), { replace: true })}
  ><QueryClientProvider client={queryClient}><TooltipProvider><QueryCacheSync /><RouterContent /><Toaster /></TooltipProvider></QueryClientProvider></ClerkProvider>;
}

function App() {
  if (!clerkPubKey) throw new Error("Missing VITE_CLERK_PUBLISHABLE_KEY.");
  return <WouterRouter base={basePath}><ClerkRouter /></WouterRouter>;
}

export default App;
