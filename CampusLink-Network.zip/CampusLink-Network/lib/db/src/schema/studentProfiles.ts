import {
  index,
  pgTable,
  text,
  timestamp,
} from "drizzle-orm/pg-core";
import { universitiesTable } from "./universities";

export const studentProfilesTable = pgTable(
  "student_profiles",
  {
    // Clerk owns the account; CampusLink never stores a password or email here.
    clerkUserId: text("clerk_user_id").primaryKey(),
    universityId: text("university_id")
      .notNull()
      .references(() => universitiesTable.id, { onDelete: "restrict" }),
    displayName: text("display_name").notNull(),
    program: text("program").notNull(),
    academicLevel: text("academic_level").notNull(),
    bio: text("bio"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => ({
    universityIndex: index("student_profiles_university_idx").on(
      table.universityId,
    ),
  }),
);

export type StudentProfile = typeof studentProfilesTable.$inferSelect;
