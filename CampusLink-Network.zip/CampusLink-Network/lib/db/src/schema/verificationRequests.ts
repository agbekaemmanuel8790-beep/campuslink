import {
  index,
  integer,
  pgEnum,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";
import { studentProfilesTable } from "./studentProfiles";
import { universitiesTable } from "./universities";
import { universityVerificationMethodsTable } from "./universityVerificationMethods";

export const studentVerificationStatus = pgEnum("student_verification_status", [
  "pending",
  "verified",
  "rejected",
]);

export const verificationRequestsTable = pgTable(
  "verification_requests",
  {
    id: serial("id").primaryKey(),
    clerkUserId: text("clerk_user_id")
      .notNull()
      .references(() => studentProfilesTable.clerkUserId, {
        onDelete: "cascade",
      }),
    universityId: text("university_id")
      .notNull()
      .references(() => universitiesTable.id, { onDelete: "restrict" }),
    methodId: integer("method_id").references(
      () => universityVerificationMethodsTable.id,
      { onDelete: "set null" },
    ),
    status: studentVerificationStatus("status").notNull().default("pending"),
    submittedAt: timestamp("submitted_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    reviewedAt: timestamp("reviewed_at", { withTimezone: true }),
    reviewedByClerkUserId: text("reviewed_by_clerk_user_id"),
    // Internal reviewer notes are never included in student-facing responses.
    decisionNote: text("decision_note"),
  },
  (table) => ({
    userIndex: index("verification_requests_user_idx").on(table.clerkUserId),
    universityStatusIndex: index("verification_requests_university_status_idx").on(
      table.universityId,
      table.status,
    ),
  }),
);

export type VerificationRequest = typeof verificationRequestsTable.$inferSelect;
