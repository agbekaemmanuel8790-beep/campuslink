import {
  boolean,
  index,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  uniqueIndex,
} from "drizzle-orm/pg-core";
import { universitiesTable } from "./universities";

export const universityVerificationMethodsTable = pgTable(
  "university_verification_methods",
  {
    id: serial("id").primaryKey(),
    universityId: text("university_id")
      .notNull()
      .references(() => universitiesTable.id, { onDelete: "restrict" }),
    methodKey: text("method_key").notNull(),
    methodType: text("method_type").notNull(),
    displayName: text("display_name").notNull(),
    enabled: boolean("enabled").notNull().default(false),
    instructions: text("instructions"),
    // Public/non-secret settings only. Provider credentials belong in Replit Secrets.
    publicConfiguration: jsonb("public_configuration")
      .$type<Record<string, unknown>>()
      .notNull()
      .default({}),
  },
  (table) => ({
    universityIndex: index("university_verification_methods_university_idx").on(
      table.universityId,
    ),
    universityMethodUnique: uniqueIndex(
      "university_verification_methods_university_method_unique",
    ).on(table.universityId, table.methodKey),
  }),
);

export type UniversityVerificationMethod =
  typeof universityVerificationMethodsTable.$inferSelect;
