import {
  index,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";
import {
  studentVerificationStatus,
  verificationRequestsTable,
} from "./verificationRequests";

export const verificationAuditTable = pgTable(
  "verification_audit",
  {
    id: serial("id").primaryKey(),
    requestId: integer("request_id")
      .notNull()
      .references(() => verificationRequestsTable.id, { onDelete: "cascade" }),
    actorClerkUserId: text("actor_clerk_user_id"),
    action: text("action").notNull(),
    previousStatus: studentVerificationStatus("previous_status"),
    newStatus: studentVerificationStatus("new_status"),
    // Keep audit metadata minimal and exclude documents or provider credentials.
    metadata: jsonb("metadata")
      .$type<Record<string, unknown>>()
      .notNull()
      .default({}),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => ({
    requestIndex: index("verification_audit_request_idx").on(table.requestId),
  }),
);

export type VerificationAuditEntry = typeof verificationAuditTable.$inferSelect;
