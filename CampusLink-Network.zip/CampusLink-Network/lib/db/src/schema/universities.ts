import { boolean, pgTable, text } from "drizzle-orm/pg-core";

export const universitiesTable = pgTable("universities", {
  id: text("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  name: text("name").notNull(),
  city: text("city").notNull(),
  country: text("country").notNull(),
  isActive: boolean("is_active").notNull().default(true),
});

export type University = typeof universitiesTable.$inferSelect;
